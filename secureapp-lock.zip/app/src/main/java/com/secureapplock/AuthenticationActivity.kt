package com.secureapplock

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import com.secureapplock.ui.theme.SecureAppLockTheme
import com.secureapplock.utils.SecurityManager

class AuthenticationActivity : FragmentActivity() {
    private lateinit var securityManager: SecurityManager
    private lateinit var targetPackage: String
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        securityManager = SecurityManager(this)
        targetPackage = intent.getStringExtra("target_package") ?: ""
        
        if (targetPackage.isEmpty()) {
            finish()
            return
        }
        
        setContent {
            SecureAppLockTheme {
                AuthenticationScreen(
                    onAuthSuccess = {
                        // Launch the target app
                        val launchIntent = packageManager.getLaunchIntentForPackage(targetPackage)
                        if (launchIntent != null) {
                            startActivity(launchIntent)
                        }
                        finish()
                    },
                    onAuthCancel = {
                        finish()
                    }
                )
            }
        }
        
        // Try biometric authentication first if enabled
        if (securityManager.isBiometricEnabled()) {
            showBiometricPrompt()
        }
    }
    
    private fun showBiometricPrompt() {
        val biometricManager = BiometricManager.from(this)
        
        if (biometricManager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK) == BiometricManager.BIOMETRIC_SUCCESS) {
            val executor = ContextCompat.getMainExecutor(this)
            val biometricPrompt = BiometricPrompt(this, executor, object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    super.onAuthenticationSucceeded(result)
                    // Launch the target app
                    val launchIntent = packageManager.getLaunchIntentForPackage(targetPackage)
                    if (launchIntent != null) {
                        startActivity(launchIntent)
                    }
                    finish()
                }
                
                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    super.onAuthenticationError(errorCode, errString)
                    // Continue with PIN authentication
                }
                
                override fun onAuthenticationFailed() {
                    super.onAuthenticationFailed()
                    // Continue with PIN authentication
                }
            })
            
            val promptInfo = BiometricPrompt.PromptInfo.Builder()
                .setTitle("Unlock App")
                .setSubtitle("Use your biometric credential to unlock this app")
                .setNegativeButtonText("Use PIN")
                .build()
            
            biometricPrompt.authenticate(promptInfo)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AuthenticationScreen(
    onAuthSuccess: () -> Unit,
    onAuthCancel: () -> Unit
) {
    val context = LocalContext.current
    val securityManager = remember { SecurityManager(context) }
    
    var pin by remember { mutableStateOf("") }
    var pinError by remember { mutableStateOf("") }
    var attempts by remember { mutableIntStateOf(0) }
    val maxAttempts = 5
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("App Locked") },
                navigationIcon = {
                    IconButton(onClick = onAuthCancel) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Cancel")
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                Icons.Default.Lock,
                contentDescription = null,
                modifier = Modifier.size(80.dp),
                tint = MaterialTheme.colorScheme.primary
            )
            
            Spacer(modifier = Modifier.height(24.dp))
            
            Text(
                text = "Enter PIN to Unlock",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Text(
                text = "This app is protected by SecureApp Lock",
                style = MaterialTheme.typography.bodyMedium,
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
            )
            
            if (attempts > 0) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Attempts remaining: ${maxAttempts - attempts}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error
                )
            }
            
            Spacer(modifier = Modifier.height(32.dp))
            
            OutlinedTextField(
                value = pin,
                onValueChange = { 
                    if (it.length <= 6 && it.all { char -> char.isDigit() }) {
                        pin = it
                        pinError = ""
                    }
                },
                label = { Text("Enter PIN") },
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                modifier = Modifier.fillMaxWidth(),
                isError = pinError.isNotEmpty(),
                enabled = attempts < maxAttempts
            )
            
            if (pinError.isNotEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = pinError,
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall
                )
            }
            
            Spacer(modifier = Modifier.height(24.dp))
            
            Button(
                onClick = {
                    if (securityManager.verifyPIN(pin)) {
                        onAuthSuccess()
                    } else {
                        attempts++
                        if (attempts >= maxAttempts) {
                            pinError = "Too many failed attempts. Please try again later."
                        } else {
                            pinError = "Incorrect PIN. Try again."
                        }
                        pin = ""
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                enabled = pin.isNotEmpty() && attempts < maxAttempts
            ) {
                Text("Unlock")
                Spacer(modifier = Modifier.width(8.dp))
                Icon(Icons.Default.LockOpen, contentDescription = null)
            }
            
            if (securityManager.isBiometricEnabled()) {
                Spacer(modifier = Modifier.height(16.dp))
                
                OutlinedButton(
                    onClick = {
                        // Trigger biometric authentication
                        (context as? AuthenticationActivity)?.showBiometricPrompt()
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Fingerprint, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Use Biometric")
                }
            }
        }
    }
}

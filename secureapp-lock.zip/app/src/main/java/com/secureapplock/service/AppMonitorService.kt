package com.secureapplock.service

import android.app.Service
import android.app.usage.UsageStats
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import com.secureapplock.AuthenticationActivity
import com.secureapplock.utils.SecurityManager

class AppMonitorService : Service() {
    
    private lateinit var securityManager: SecurityManager
    private lateinit var usageStatsManager: UsageStatsManager
    private val handler = Handler(Looper.getMainLooper())
    private var monitoringRunnable: Runnable? = null
    private var lastCheckedApp = ""
    
    companion object {
        private const val MONITORING_INTERVAL = 1000L // 1 second
    }
    
    override fun onCreate() {
        super.onCreate()
        securityManager = SecurityManager(this)
        usageStatsManager = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        startMonitoring()
    }
    
    override fun onBind(intent: Intent?): IBinder? = null
    
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }
    
    private fun startMonitoring() {
        monitoringRunnable = object : Runnable {
            override fun run() {
                checkCurrentApp()
                handler.postDelayed(this, MONITORING_INTERVAL)
            }
        }
        handler.post(monitoringRunnable!!)
    }
    
    private fun checkCurrentApp() {
        val currentTime = System.currentTimeMillis()
        val stats = usageStatsManager.queryUsageStats(
            UsageStatsManager.INTERVAL_DAILY,
            currentTime - MONITORING_INTERVAL * 2,
            currentTime
        )
        
        if (stats.isNotEmpty()) {
            val sortedStats = stats.sortedByDescending { it.lastTimeUsed }
            val currentApp = sortedStats.firstOrNull()
            
            currentApp?.let { usageStats ->
                val packageName = usageStats.packageName
                
                // Avoid checking the same app repeatedly and ignore our own app
                if (packageName != lastCheckedApp && 
                    packageName != this.packageName &&
                    securityManager.isAppLocked(packageName)) {
                    
                    lastCheckedApp = packageName
                    showAuthenticationScreen(packageName)
                }
            }
        }
    }
    
    private fun showAuthenticationScreen(packageName: String) {
        val intent = Intent(this, AuthenticationActivity::class.java).apply {
            putExtra("target_package", packageName)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }
        startActivity(intent)
    }
    
    override fun onDestroy() {
        super.onDestroy()
        monitoringRunnable?.let { handler.removeCallbacks(it) }
    }
}

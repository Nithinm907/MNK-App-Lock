package com.secureapplock.utils

import android.content.Context
import android.content.SharedPreferences
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

class SecurityManager(private val context: Context) {
    
    companion object {
        private const val PREFS_NAME = "secure_app_lock_prefs"
        private const val KEY_PIN_HASH = "pin_hash"
        private const val KEY_PIN_SALT = "pin_salt"
        private const val KEY_BIOMETRIC_ENABLED = "biometric_enabled"
        private const val KEY_SETUP_COMPLETE = "setup_complete"
        private const val KEY_LOCKED_APPS = "locked_apps"
        private const val KEYSTORE_ALIAS = "SecureAppLockKey"
    }
    
    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()
    
    private val encryptedPrefs: SharedPreferences = EncryptedSharedPreferences.create(
        context,
        PREFS_NAME,
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )
    
    fun savePIN(pin: String) {
        val salt = generateSalt()
        val hashedPin = hashPIN(pin, salt)
        
        encryptedPrefs.edit()
            .putString(KEY_PIN_HASH, hashedPin)
            .putString(KEY_PIN_SALT, salt)
            .apply()
    }
    
    fun verifyPIN(pin: String): Boolean {
        val storedHash = encryptedPrefs.getString(KEY_PIN_HASH, null) ?: return false
        val salt = encryptedPrefs.getString(KEY_PIN_SALT, null) ?: return false
        
        val hashedPin = hashPIN(pin, salt)
        return hashedPin == storedHash
    }
    
    private fun generateSalt(): String {
        val salt = ByteArray(16)
        SecureRandom().nextBytes(salt)
        return android.util.Base64.encodeToString(salt, android.util.Base64.DEFAULT)
    }
    
    private fun hashPIN(pin: String, salt: String): String {
        val saltBytes = android.util.Base64.decode(salt, android.util.Base64.DEFAULT)
        val digest = MessageDigest.getInstance("SHA-256")
        digest.update(saltBytes)
        val hashedBytes = digest.digest(pin.toByteArray())
        return android.util.Base64.encodeToString(hashedBytes, android.util.Base64.DEFAULT)
    }
    
    fun setBiometricEnabled(enabled: Boolean) {
        encryptedPrefs.edit()
            .putBoolean(KEY_BIOMETRIC_ENABLED, enabled)
            .apply()
    }
    
    fun isBiometricEnabled(): Boolean {
        return encryptedPrefs.getBoolean(KEY_BIOMETRIC_ENABLED, false)
    }
    
    fun setSetupComplete(complete: Boolean) {
        encryptedPrefs.edit()
            .putBoolean(KEY_SETUP_COMPLETE, complete)
            .apply()
    }
    
    fun isSetupComplete(): Boolean {
        return encryptedPrefs.getBoolean(KEY_SETUP_COMPLETE, false)
    }
    
    fun addLockedApp(packageName: String) {
        val lockedApps = getLockedApps().toMutableSet()
        lockedApps.add(packageName)
        saveLockedApps(lockedApps)
    }
    
    fun removeLockedApp(packageName: String) {
        val lockedApps = getLockedApps().toMutableSet()
        lockedApps.remove(packageName)
        saveLockedApps(lockedApps)
    }
    
    fun getLockedApps(): Set<String> {
        val appsString = encryptedPrefs.getString(KEY_LOCKED_APPS, "") ?: ""
        return if (appsString.isEmpty()) {
            emptySet()
        } else {
            appsString.split(",").toSet()
        }
    }
    
    private fun saveLockedApps(apps: Set<String>) {
        val appsString = apps.joinToString(",")
        encryptedPrefs.edit()
            .putString(KEY_LOCKED_APPS, appsString)
            .apply()
    }
    
    fun isAppLocked(packageName: String): Boolean {
        return getLockedApps().contains(packageName)
    }
}

package com.secureapplock.viewmodel

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.secureapplock.AppInfo
import com.secureapplock.utils.SecurityManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class AppSelectionViewModel : ViewModel() {
    
    private val _installedApps = MutableStateFlow<List<AppInfo>>(emptyList())
    val installedApps: StateFlow<List<AppInfo>> = _installedApps
    
    private val _lockedApps = MutableStateFlow<List<AppInfo>>(emptyList())
    val lockedApps: StateFlow<List<AppInfo>> = _lockedApps
    
    fun loadInstalledApps(context: Context) {
        viewModelScope.launch(Dispatchers.IO) {
            val packageManager = context.packageManager
            
            val apps = packageManager.getInstalledApplications(PackageManager.GET_META_DATA)
                .filter { app ->
                    // Filter out system apps and apps without launch intent
                    packageManager.getLaunchIntentForPackage(app.packageName) != null &&
                    app.packageName != context.packageName // Exclude our own app
                }
                .map { app ->
                    AppInfo(
                        name = app.loadLabel(packageManager).toString(),
                        packageName = app.packageName,
                        isSystemApp = (app.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                    )
                }
                .sortedBy { it.name }
            
            _installedApps.value = apps
        }
    }
    
    fun loadLockedApps(context: Context) {
        viewModelScope.launch(Dispatchers.IO) {
            val securityManager = SecurityManager(context)
            val packageManager = context.packageManager
            
            val lockedPackages = securityManager.getLockedApps()
            val lockedAppsList = lockedPackages.mapNotNull { packageName ->
                try {
                    val appInfo = packageManager.getApplicationInfo(packageName, 0)
                    AppInfo(
                        name = appInfo.loadLabel(packageManager).toString(),
                        packageName = packageName,
                        isSystemApp = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                    )
                } catch (e: PackageManager.NameNotFoundException) {
                    null
                }
            }
            
            _lockedApps.value = lockedAppsList
        }
    }
    
    fun addLockedApp(context: Context, app: AppInfo) {
        val securityManager = SecurityManager(context)
        securityManager.addLockedApp(app.packageName)
        
        // Update the locked apps list
        _lockedApps.value = _lockedApps.value + app
    }
    
    fun removeLockedApp(context: Context, packageName: String) {
        val securityManager = SecurityManager(context)
        securityManager.removeLockedApp(packageName)
        
        // Update the locked apps list
        _lockedApps.value = _lockedApps.value.filter { it.packageName != packageName }
    }
}

package com.secureapplock.viewmodel

import androidx.lifecycle.ViewModel

class SetupViewModel : ViewModel() {
    // This ViewModel can be expanded to handle setup-specific logic
    // For now, the setup logic is handled directly in the Composable
}
